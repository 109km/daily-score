User

* id
* mobile
* password
* nickname
* avatar

Task

* id
* content
* score_unit
* total_score
* start_time
* end_time
* date
